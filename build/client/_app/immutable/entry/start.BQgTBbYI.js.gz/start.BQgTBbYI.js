import{l as o,a as r}from"../chunks/BwD15NmI.js";export{o as load_css,r as start};
