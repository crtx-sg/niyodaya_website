import{l as o,a as r}from"../chunks/BWv2vy8g.js";export{o as load_css,r as start};
